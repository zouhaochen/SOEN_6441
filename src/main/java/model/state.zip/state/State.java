package model.state;

/**
 * game state interface
 */
public interface State {
}
